"""
Second Positional Servo Test Tool — runs on the Raspberry Pi 5.

Standalone. Does NOT import or touch dispenser_test.py / dispenser_daemon.py —
that's a separate positional servo on GPIO 12 already wired into the kiosk.
This tool is for testing a SECOND positional servo on its own pin (GPIO 17).

History: this was originally written assuming the servo was continuous-
rotation (no position feedback, pulse width = speed). On the real hardware
it turned out to behave as a normal positional servo instead — sending it a
"speed" pulse just moved it to a new held angle, which looked like glitter/
stalling under the wrong (continuous-rotation) model. Measured by hand, this
unit's real pulse range is ~700-2300µs across its 0-180° sweep, so it's now
calibrated and driven the same way dispenser_test.py drives its servo.

Hardware (servo → Pi 5):
    Signal (orange/yellow) → GPIO 17  (physical pin 11)
    V+     (red)           → 5V        (dedicated 5V/1-2A+ supply — do NOT use
                                         an MCU's Vin/USB-derived rail, e.g. an
                                         ESP32's Vin off a PC USB port: that has
                                         nowhere near enough current headroom and
                                         will brown out under load)
    GND    (brown/black)   → GND       (MUST share GND with the Pi)

Pulse: 50 Hz period. MIN_PULSE_US = 0°, MAX_PULSE_US = MAX_ANGLE° (now 0-300°).
The pulse endpoints map to the servo's physical end-stops, so measure YOUR
servo and set MIN_PULSE_US / MAX_PULSE_US so 0° and 300° hit the true limits
(a 270/300° servo is often ~500-2500 µs). Widening the angle number alone does
NOT make the servo travel further — the pulse range does.
NOTE: the --hw (kernel hardware-PWM) mode relies on the pwm-2chan overlay,
which only covers GPIO 12/13. GPIO 18 is NOT on that overlay, so on this pin
use plain software mode (run without --hw).

Setup for software mode (on the Pi, once):
    pip install gpiozero lgpio

Run:
    python3 servo_360_calibrate.py             # interactive, software PWM
    sudo python3 servo_360_calibrate.py --hw   # interactive, hardware PWM

Interactive keys:
    0 = 0°   9 = 300°   m = 150°   a<NN> = go to angle NN (0-300)
    s = sweep 0<->300 x5   b = button motion (90 -> 180 -> back to 90)
    x = detach   p<NN> = change pin (software mode)   q = quit
"""

import os
import sys
import glob
import time

SERVO_PIN     = 17       # BCM (physical pin 11) — free GPIO; GPIO18/pin12 was busy (held by audio/another process)
MIN_PULSE_US  = 700       # pulse at 0°   (verified: a0 -> 0°)
MAX_PULSE_US  = 3900      # pulse at 300° (derived from measured a90->45°, a180->90°: ~10.67 µs/deg)
MAX_ANGLE     = 300       # command degrees now == physical degrees
PERIOD_US     = 20000     # 50 Hz
HW_CHANNEL    = 1         # only used in --hw mode (pwm-2chan, GPIO 12/13). N/A for GPIO 18 -> use software PWM

SWEEP_DELAY_S = 0.7

USE_HW = False            # set by --hw


# ── Hardware PWM backend (kernel /sys/class/pwm) ────────────────────────────
class SysfsServo:
    """Drives a positional servo via the kernel hardware-PWM. Mimics gpiozero's .angle API."""

    def __init__(self, channel=HW_CHANNEL, chip=None):
        self.chip = chip or self._find_chip()
        if not self.chip:
            raise RuntimeError(
                "No /sys/class/pwm chip found. Enable the overlay + reboot:\n"
                "  echo 'dtoverlay=pwm-2chan,pin=12,func=4,pin2=13,func2=4'"
                " | sudo tee -a /boot/firmware/config.txt && sudo reboot")
        self.ch   = channel
        self.base = f"{self.chip}/pwm{channel}"
        print(f"[hw] using {self.chip} channel {channel}")
        if not os.path.isdir(self.base):
            self._w(f"{self.chip}/export", channel)
            time.sleep(0.2)
        self._w(f"{self.base}/period", PERIOD_US * 1000)   # ns
        self._enabled = False
        self.angle = 0

    @staticmethod
    def _find_chip():
        for c in sorted(glob.glob("/sys/class/pwm/pwmchip*")):
            try:
                with open(os.path.join(c, "npwm")) as f:
                    if int(f.read().strip()) >= 2:
                        return c
            except OSError:
                continue
        return None

    def _w(self, path, val):
        try:
            with open(path, "w") as f:
                f.write(str(val))
        except PermissionError:
            raise RuntimeError("Permission denied on sysfs PWM — run with sudo.")

    @property
    def angle(self):
        return self._angle

    @angle.setter
    def angle(self, a):
        if a is None:                       # detach -> stop output
            self._w(f"{self.base}/enable", 0)
            self._enabled = False
            self._angle = None
            return
        a = max(0, min(MAX_ANGLE, a))
        us = MIN_PULSE_US + (a / float(MAX_ANGLE)) * (MAX_PULSE_US - MIN_PULSE_US)
        self._w(f"{self.base}/duty_cycle", int(us * 1000))   # ns
        if not self._enabled:
            self._w(f"{self.base}/enable", 1)
            self._enabled = True
        self._angle = a

    def close(self):
        try:
            self.angle = None
        except Exception:
            pass


# ── Software PWM backend (gpiozero / lgpio) ─────────────────────────────────
def _make_gpiozero(pin):
    from gpiozero import AngularServo
    return AngularServo(
        pin,
        min_angle=0, max_angle=MAX_ANGLE,
        min_pulse_width=MIN_PULSE_US / 1e6,
        max_pulse_width=MAX_PULSE_US / 1e6,
        initial_angle=0,
    )


def make_servo(pin):
    return SysfsServo(channel=HW_CHANNEL) if USE_HW else _make_gpiozero(pin)


# ── Motions (backend-agnostic via the .angle API) ───────────────────────────
def sweep(servo, cycles=5):
    print(f"[servo] sweeping {cycles}x ...")
    for _ in range(cycles):
        servo.angle = 0
        time.sleep(SWEEP_DELAY_S)
        servo.angle = MAX_ANGLE
        time.sleep(SWEEP_DELAY_S)
    servo.angle = None
    print("[servo] sweep done (detached).")


def button_sweep(servo, hold_s=0.6):
    """One button-press cycle: 90 -> 180 -> back to 90."""
    print("[servo] 90 -> 180 ...")
    servo.angle = 90
    time.sleep(0.3)
    servo.angle = 180
    time.sleep(hold_s)
    print("[servo] ... back to 90")
    servo.angle = 90
    time.sleep(0.3)
    servo.angle = None
    print("[servo] done (detached).")


def main():
    global USE_HW
    USE_HW = "--hw" in sys.argv

    pin = SERVO_PIN
    servo = make_servo(pin)
    print("\n=== Second Positional Servo Test ===")
    print(f"Backend: {'HARDWARE' if USE_HW else 'software'} PWM   |   GPIO {pin}   |   "
          f"50 Hz, {MIN_PULSE_US}-{MAX_PULSE_US} µs, 0-{MAX_ANGLE}°")
    print(f"Keys: 0=0deg 9={MAX_ANGLE}deg m={MAX_ANGLE // 2}deg a<NN>=angle s=sweep b=90->180->90 x=detach p<NN>=pin q=quit\n")

    try:
        while True:
            cmd = input("> ").strip().lower()
            if not cmd:
                continue
            key = cmd[0]
            if key == "q":
                break
            elif key == "0":
                servo.angle = 0;   print("-> 0°")
            elif key == "9":
                servo.angle = MAX_ANGLE; print(f"-> {MAX_ANGLE}°")
            elif key == "m":
                servo.angle = MAX_ANGLE // 2;  print(f"-> {MAX_ANGLE // 2}°")
            elif key == "a":
                arg = cmd[1:].strip()
                if arg.isdigit() and 0 <= int(arg) <= MAX_ANGLE:
                    servo.angle = int(arg)
                    print(f"-> {arg}°")
                else:
                    print(f"usage: a<0-{MAX_ANGLE}>  e.g. a150")
            elif key == "s":
                sweep(servo)
            elif key == "b":
                button_sweep(servo)
            elif key == "x":
                servo.angle = None; print("[servo] detached (limp).")
            elif key == "p" and not USE_HW:
                arg = cmd[1:].strip()
                if arg.isdigit():
                    servo.close()
                    pin = int(arg)
                    servo = make_servo(pin)
                    print(f"[servo] now on GPIO {pin} (parked at 0°)")
                else:
                    print("usage: p<pin>  e.g. p13")
            else:
                print("keys: 0 9 m a<NN> s b x p<NN> q")
    except (KeyboardInterrupt, EOFError):
        print()
    finally:
        servo.close()
        print("Closed. Bye.")


if __name__ == "__main__":
    sys.exit(main())
