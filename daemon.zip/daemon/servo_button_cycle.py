"""
Button-Cycle Positional Servo Tool — runs on the Raspberry Pi 5.

Standalone — separate from dispenser_test.py / dispenser_daemon.py (GPIO 12)
and from servo_360_calibrate.py.

This was originally written assuming a 360°-range servo, but hardware testing
(commanding a0 -> a220 on the old 0-360° scale) showed it physically hits its
mechanical end stop at 180°, same as the other unit — so this is a normal
0-180° positional servo after all, just with a different measured pulse range:

    t  -> turn: move straight to 150° from wherever it currently is.
    n  -> reset: move back down to 0° first, then sweep up to 150° again
          (a full fresh cycle, discarding wherever 't' had left it).
          (150° is a deliberate target short of the 180° mechanical limit —
          see TARGET_ANGLE below; the calibrated 0-180° pulse range itself
          is unchanged, still verifiable with `a<NN>`.)

Hardware (servo → Pi 5):
    Signal (orange/yellow) → GPIO 13  (physical pin 33)
    V+     (red)           → 5V        (dedicated 5V/1-2A+ supply — do NOT use
                                         an MCU's Vin/USB-derived rail)
    GND    (brown/black)   → GND       (MUST share GND with the Pi)

Pulse: 50 Hz period, 700 µs = 0°, 2656 µs = 180° — derived from the a0/a220
hardware test (a220 on the old 700-3900µs/0-360° scale = 2656µs, which is
where it actually hit 180°). Use `a<NN>` to double check and nudge
MIN_PULSE_US/MAX_PULSE_US further if 0°/180° aren't quite exact.

Run:
    python3 servo_button_cycle.py             # interactive, software PWM
    sudo python3 servo_button_cycle.py --hw   # interactive, hardware PWM

Interactive keys:
    t = turn (move to 150° from current position)
    n = reset (move to 0°, then turn to 150° again)
    a<NN> = go to angle NN (0-180) — use this to verify/tune the pulse range
    x = detach   p<NN> = change pin (software mode only)   q = quit
"""

import os
import sys
import glob
import time

SERVO_PIN     = 13       # BCM
MIN_PULSE_US  = 700       # 0°   (measured: a0)
MAX_PULSE_US  = 2656      # 180° (measured: a220 on the old 0-360 scale)
MAX_ANGLE     = 180       # calibrated mechanical range (for a<NN> / clamping)
TARGET_ANGLE  = 150       # what t/n actually turn to
PERIOD_US     = 20000     # 50 Hz
HW_CHANNEL    = 1         # GPIO 13 = channel 1 on the pwm-2chan overlay

SETTLE_S      = 0.5       # pause after each move so it visibly completes

USE_HW = False            # set by --hw


# ── Hardware PWM backend (kernel /sys/class/pwm) ────────────────────────────
class SysfsServo:
    """Drives a positional servo via the kernel hardware-PWM. Mimics gpiozero's .angle API."""

    def __init__(self, channel=HW_CHANNEL, chip=None):
        self.chip = chip or self._find_chip()
        if not self.chip:
            raise RuntimeError(
                "No /sys/class/pwm chip found. Enable the overlay + reboot:\n"
                "  echo 'dtoverlay=pwm-2chan,pin=12,func=4,pin2=13,func2=4'"
                " | sudo tee -a /boot/firmware/config.txt && sudo reboot")
        self.ch   = channel
        self.base = f"{self.chip}/pwm{channel}"
        print(f"[hw] using {self.chip} channel {channel}")
        if not os.path.isdir(self.base):
            self._w(f"{self.chip}/export", channel)
            time.sleep(0.2)
        self._w(f"{self.base}/period", PERIOD_US * 1000)   # ns
        self._enabled = False
        self.angle = 0

    @staticmethod
    def _find_chip():
        for c in sorted(glob.glob("/sys/class/pwm/pwmchip*")):
            try:
                with open(os.path.join(c, "npwm")) as f:
                    if int(f.read().strip()) >= 2:
                        return c
            except OSError:
                continue
        return None

    def _w(self, path, val):
        try:
            with open(path, "w") as f:
                f.write(str(val))
        except PermissionError:
            raise RuntimeError("Permission denied on sysfs PWM — run with sudo.")

    @property
    def angle(self):
        return self._angle

    @angle.setter
    def angle(self, a):
        if a is None:                       # detach -> stop output
            self._w(f"{self.base}/enable", 0)
            self._enabled = False
            self._angle = None
            return
        a = max(0, min(MAX_ANGLE, a))
        us = MIN_PULSE_US + (a / MAX_ANGLE) * (MAX_PULSE_US - MIN_PULSE_US)
        self._w(f"{self.base}/duty_cycle", int(us * 1000))   # ns
        if not self._enabled:
            self._w(f"{self.base}/enable", 1)
            self._enabled = True
        self._angle = a

    def close(self):
        try:
            self.angle = None
        except Exception:
            pass


# ── Software PWM backend (gpiozero / lgpio) ─────────────────────────────────
def _make_gpiozero(pin):
    from gpiozero import AngularServo
    return AngularServo(
        pin,
        min_angle=0, max_angle=MAX_ANGLE,
        min_pulse_width=MIN_PULSE_US / 1e6,
        max_pulse_width=MAX_PULSE_US / 1e6,
        initial_angle=0,
    )


def make_servo(pin):
    return SysfsServo(channel=HW_CHANNEL) if USE_HW else _make_gpiozero(pin)


# ── Motions ──────────────────────────────────────────────────────────────────
def turn(servo):
    """Move straight to TARGET_ANGLE from wherever the servo currently is."""
    print(f"[servo] turn: {servo.angle}° -> {TARGET_ANGLE}° ...")
    servo.angle = TARGET_ANGLE
    time.sleep(SETTLE_S)
    print("[servo] done.")


def reset_and_turn(servo):
    """Clear the previous turn: drop back to 0°, then sweep up to TARGET_ANGLE again."""
    print(f"[servo] reset: {servo.angle}° -> 0° ...")
    servo.angle = 0
    time.sleep(SETTLE_S)
    print(f"[servo] ... 0° -> {TARGET_ANGLE}°")
    servo.angle = TARGET_ANGLE
    time.sleep(SETTLE_S)
    print("[servo] done.")


def main():
    global USE_HW
    USE_HW = "--hw" in sys.argv

    pin = SERVO_PIN
    servo = make_servo(pin)
    print("\n=== Button-Cycle Positional Servo Tool ===")
    print(f"Backend: {'HARDWARE' if USE_HW else 'software'} PWM   |   GPIO {pin}   |   "
          f"50 Hz, {MIN_PULSE_US}-{MAX_PULSE_US} µs")
    print(f"Keys: t=turn (->{TARGET_ANGLE})   n=reset (->0->{TARGET_ANGLE})   a<NN>=angle(0-{MAX_ANGLE})   "
          f"x=detach   p<NN>=pin   q=quit\n")

    try:
        while True:
            cmd = input("> ").strip().lower()
            if not cmd:
                continue
            key = cmd[0]

            if key == "q":
                break
            elif key == "t":
                turn(servo)
            elif key == "n":
                reset_and_turn(servo)
            elif key == "a":
                arg = cmd[1:].strip()
                if arg.isdigit() and 0 <= int(arg) <= MAX_ANGLE:
                    servo.angle = int(arg)
                    print(f"-> {arg}°")
                else:
                    print(f"usage: a<0-{MAX_ANGLE}>  e.g. a90")
            elif key == "x":
                servo.angle = None
                print("[servo] detached (limp).")
            elif key == "p" and not USE_HW:
                arg = cmd[1:].strip()
                if arg.isdigit():
                    servo.close()
                    pin = int(arg)
                    servo = make_servo(pin)
                    print(f"[servo] now on GPIO {pin} (parked at 0°)")
                else:
                    print("usage: p<pin>  e.g. p13")
            else:
                print(f"keys: t n a<0-{MAX_ANGLE}> x p<NN> q")
    except (KeyboardInterrupt, EOFError):
        print()
    finally:
        servo.close()
        print("Closed. Bye.")


if __name__ == "__main__":
    sys.exit(main())
