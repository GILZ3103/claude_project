"""
Second Positional Servo — 210° Hold-and-Repeat Cycle — runs on the Raspberry Pi 5.

Standalone — separate from dispenser_test.py / dispenser_daemon.py (GPIO 12 BCM,
physical pin 32 — the existing kiosk card dispenser). Drives a SECOND servo (SG90)
on its own pin.

Behavior: pressing 'n' runs this sequence twice:
    0° -> 210° -> hold 5s -> back to 0°

210° exceeds the SG90's typical ~180° rated travel. This script assumes YOUR unit has
been confirmed (e.g. with the a<NN> command in servo_360_calibrate.py) to physically
reach 210° without hitting its mechanical end-stop. Commanding a stalled motor past its
real limit risks burning out the gears/motor — verify on the bench first if unsure.

Hardware (servo → Pi 5):
    Signal (orange/yellow) → GPIO 18  (physical pin 12)
    V+     (red)           → 5V        (SG90 draws ~100-250 mA running, ~650 mA stall —
                                         Pi's own 5V pin or a dedicated supply both work)
    GND    (brown/black)   → GND       (MUST share GND with the Pi)

CALIBRATE FIRST: pulse width <-> angle mapping is specific to your physical servo unit.
MIN_PULSE_US/MAX_PULSE_US below are extrapolated defaults, not measured. Use
servo_360_calibrate.py's a<NN> command on this servo to find the real pulse values for
0° and 210°, then update the two constants below to match before relying on this script.

Setup (on the Pi, once):
    pip install gpiozero lgpio

Run:
    python3 servo_210_cycle.py

Keys:
    n = run the cycle (0 -> 210°, hold 5s, -> 0°), twice
    0 = 0°   2 = 210°   a<NN> = go to angle NN (0-210)   x = detach   q = quit
"""

import sys
import time

SERVO_PIN     = 18       # BCM (physical pin 12)
MIN_PULSE_US  = 500      # 0°   — extrapolated default, VERIFY with servo_360_calibrate.py
MAX_PULSE_US  = 2700     # 210° — extrapolated default, VERIFY with servo_360_calibrate.py
MAX_ANGLE     = 210

HOLD_S        = 2        # how long to hold at 210°
REPEAT_COUNT  = 3         # how many times 'n' repeats the cycle


def make_servo(pin=SERVO_PIN):
    from gpiozero import AngularServo
    return AngularServo(
        pin,
        min_angle=0, max_angle=MAX_ANGLE,
        min_pulse_width=MIN_PULSE_US / 1e6,
        max_pulse_width=MAX_PULSE_US / 1e6,
        initial_angle=0,
    )


def hold_cycle(servo):
    for i in range(1, REPEAT_COUNT + 1):
        print(f"[servo] cycle {i}/{REPEAT_COUNT}: 0° -> {MAX_ANGLE}°")
        servo.angle = MAX_ANGLE
        time.sleep(HOLD_S)
        print(f"[servo] cycle {i}/{REPEAT_COUNT}: -> 0°")
        servo.angle = 0
        time.sleep(0.5)
    servo.angle = None
    print("[servo] cycle complete (detached).")


def main():
    servo = make_servo()
    print("\n=== Second Servo: 210° Hold-and-Repeat Cycle ===")
    print(f"GPIO {SERVO_PIN}   |   50 Hz, {MIN_PULSE_US}-{MAX_PULSE_US} µs   |   0-{MAX_ANGLE}°")
    print(f"Keys: n=run cycle ({REPEAT_COUNT}x: 0->{MAX_ANGLE}°, hold {HOLD_S}s)   "
          f"0=0deg   2={MAX_ANGLE}deg   a<NN>=angle   x=detach   q=quit\n")

    try:
        while True:
            cmd = input("> ").strip().lower()
            if not cmd:
                continue
            key = cmd[0]
            if key == "q":
                break
            elif key == "n":
                hold_cycle(servo)
            elif key == "0":
                servo.angle = 0; print("-> 0°")
            elif key == "2":
                servo.angle = MAX_ANGLE; print(f"-> {MAX_ANGLE}°")
            elif key == "a":
                arg = cmd[1:].strip()
                if arg.isdigit() and 0 <= int(arg) <= MAX_ANGLE:
                    servo.angle = int(arg)
                    print(f"-> {arg}°")
                else:
                    print(f"usage: a<0-{MAX_ANGLE}>  e.g. a210")
            elif key == "x":
                servo.angle = None; print("[servo] detached (limp).")
            else:
                print("keys: n 0 2 a<NN> x q")
    except (KeyboardInterrupt, EOFError):
        print()
    finally:
        try:
            servo.angle = None
        except Exception:
            pass
        print("Closed. Bye.")


if __name__ == "__main__":
    sys.exit(main())
