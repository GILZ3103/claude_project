"""
Dispenser Servo Isolation Test — runs on the Raspberry Pi 5.
Drives ONLY the card-dispenser servo so you can confirm it physically moves
and is on the right GPIO BEFORE wiring it into the dispenser daemon / kiosk.

No Flask, no kiosk, no network — just the servo.

Hardware (servo → Pi 5):
    Signal (orange/yellow) → GPIO 12  (physical pin 32)
    V+     (red)           → 5V        (USE a separate 5V supply if it jitters/browns out)
    GND    (brown/black)   → GND       (MUST share GND with the Pi)

Pulse config matches the old ESP32 firmware exactly:
    50 Hz period, 544 µs = 0°, 2400 µs = 180°.

────────────────────────────────────────────────────────────────────────────
TWO PWM BACKENDS
────────────────────────────────────────────────────────────────────────────
  software (default) : gpiozero/lgpio bit-banged PWM. Easy, but on the Pi 5 it
                       is jittery and some servos ignore it entirely.
  hardware (--hw)    : kernel hardware PWM via /sys/class/pwm. Rock-solid.
                       Requires enabling the overlay ONCE + running as root:

      # 1) enable hw PWM on GPIO 12/13 (one time), then reboot:
      echo 'dtoverlay=pwm-2chan,pin=12,func=4,pin2=13,func2=4' | sudo tee -a /boot/firmware/config.txt
      sudo reboot

      # 2) after reboot, run with sudo (sysfs PWM needs root):
      sudo python3 ~/dispenser_test.py --hw --sweep

Setup for software mode (on the Pi, once):
    pip install gpiozero lgpio      # both preinstalled on Pi OS Bookworm

Run:
    python3 dispenser_test.py              # interactive, software PWM
    python3 dispenser_test.py --sweep      # one-shot 5x sweep, software PWM
    sudo python3 dispenser_test.py --hw --sweep   # one-shot sweep, hardware PWM

Keys (interactive):
    d = dispense (180° → hold → home)   0/9/m = 0°/180°/90°
    s = sweep 5x   x = detach   p<NN> = change pin (software mode)   q = quit

What you should see:
    - Horn physically swings between positions.
    - Twitches/buzzes but won't move → POWER: separate 5V + COMMON GND with the Pi.
    - Nothing in software mode → try --hw (most common Pi 5 fix).
    - Nothing even in --hw → wiring/servo/pin. Verify signal is on pin 32 (GPIO 12).
"""

import os
import sys
import glob
import time

SERVO_PIN     = 12        # BCM — matches the Pi pin chosen for the daemon
MIN_PULSE_US  = 544       # 0°   (same as firmware SERVO_US_MIN)
MAX_PULSE_US  = 2400      # 180° (same as firmware SERVO_US_MAX)
PERIOD_US     = 20000     # 50 Hz

# Dispense motion timing (same as old firmware dispenseCard())
DISPENSE_HOLD_S   = 0.6   # hold at 180° long enough to clear the card slot
DISPENSE_SETTLE_S = 0.3   # settle back home before the next command

USE_HW = False            # set by --hw


# ── Hardware PWM backend (kernel /sys/class/pwm) ────────────────────────────────
class SysfsServo:
    """Drives a servo via the kernel hardware-PWM. Mimics gpiozero's .angle API."""

    def __init__(self, channel=0, chip=None):
        self.chip = chip or self._find_chip()
        if not self.chip:
            raise RuntimeError(
                "No /sys/class/pwm chip found. Enable the overlay + reboot:\n"
                "  echo 'dtoverlay=pwm-2chan,pin=12,func=4,pin2=13,func2=4'"
                " | sudo tee -a /boot/firmware/config.txt && sudo reboot")
        self.ch   = channel
        self.base = f"{self.chip}/pwm{channel}"
        print(f"[hw] using {self.chip} channel {channel}")
        if not os.path.isdir(self.base):
            self._w(f"{self.chip}/export", channel)
            time.sleep(0.2)
        self._w(f"{self.base}/period", PERIOD_US * 1000)   # ns
        self._enabled = False
        self.angle = 0

    @staticmethod
    def _find_chip():
        # Pick a pwmchip exposing >=2 channels (the pwm-2chan overlay).
        for c in sorted(glob.glob("/sys/class/pwm/pwmchip*")):
            try:
                with open(os.path.join(c, "npwm")) as f:
                    if int(f.read().strip()) >= 2:
                        return c
            except OSError:
                continue
        return None

    def _w(self, path, val):
        try:
            with open(path, "w") as f:
                f.write(str(val))
        except PermissionError:
            raise RuntimeError("Permission denied on sysfs PWM — run with sudo.")

    @property
    def angle(self):
        return self._angle

    @angle.setter
    def angle(self, a):
        if a is None:                       # detach → stop output
            self._w(f"{self.base}/enable", 0)
            self._enabled = False
            self._angle = None
            return
        a = max(0, min(180, a))
        us = MIN_PULSE_US + (a / 180.0) * (MAX_PULSE_US - MIN_PULSE_US)
        self._w(f"{self.base}/duty_cycle", int(us * 1000))   # ns
        if not self._enabled:
            self._w(f"{self.base}/enable", 1)
            self._enabled = True
        self._angle = a

    def close(self):
        try:
            self.angle = None
        except Exception:
            pass


# ── Software PWM backend (gpiozero / lgpio) ─────────────────────────────────────
def _make_gpiozero(pin):
    from gpiozero import AngularServo
    return AngularServo(
        pin,
        min_angle=0, max_angle=180,
        min_pulse_width=MIN_PULSE_US / 1e6,
        max_pulse_width=MAX_PULSE_US / 1e6,
        initial_angle=0,
    )


def make_servo(pin):
    return SysfsServo(channel=0) if USE_HW else _make_gpiozero(pin)


# ── Motions (backend-agnostic via the .angle API) ───────────────────────────────
def dispense(servo):
    print("[servo] dispense: 180° ...")
    servo.angle = 180
    time.sleep(DISPENSE_HOLD_S)
    print("[servo] ... return home 0°")
    servo.angle = 0
    time.sleep(DISPENSE_SETTLE_S)
    servo.angle = None
    print("[servo] done (detached).")


def sweep(servo, cycles=5):
    print(f"[servo] sweeping {cycles}x ...")
    for _ in range(cycles):
        servo.angle = 0
        time.sleep(0.7)
        servo.angle = 180
        time.sleep(0.7)
    servo.angle = None
    print("[servo] sweep done (detached).")


def run_once(mode):
    servo = make_servo(SERVO_PIN)
    print(f"=== one-shot ({'hardware' if USE_HW else 'software'} PWM) on GPIO {SERVO_PIN} ===")
    try:
        sweep(servo) if mode == "sweep" else dispense(servo)
    finally:
        servo.close()
    print("Closed.")
    return 0


def main():
    global USE_HW
    USE_HW = "--hw" in sys.argv

    if "--sweep" in sys.argv:
        return run_once("sweep")
    if "--once" in sys.argv or "--dispense" in sys.argv:
        return run_once("once")

    pin = SERVO_PIN
    servo = make_servo(pin)
    print("\n=== Dispenser Servo Isolation Test ===")
    print(f"Backend: {'HARDWARE' if USE_HW else 'software'} PWM   |   GPIO {pin}   |   "
          f"50 Hz, {MIN_PULSE_US}-{MAX_PULSE_US} µs")
    print("Keys: d=dispense 0=home 9=180 m=90 s=sweep x=detach p<NN>=pin q=quit\n")

    try:
        while True:
            cmd = input("> ").strip().lower()
            if not cmd:
                continue
            key = cmd[0]
            if key == "q":
                break
            elif key == "d":
                dispense(servo)
            elif key == "0":
                servo.angle = 0;   print("-> 0° (home)")
            elif key == "9":
                servo.angle = 180; print("-> 180°")
            elif key == "m":
                servo.angle = 90;  print("-> 90°")
            elif key == "s":
                sweep(servo)
            elif key == "x":
                servo.angle = None; print("[servo] detached (limp).")
            elif key == "p" and not USE_HW:
                arg = cmd[1:].strip()
                if arg.isdigit():
                    servo.close()
                    pin = int(arg)
                    servo = make_servo(pin)
                    print(f"[servo] now on GPIO {pin} (parked at 0°)")
                else:
                    print("usage: p<pin>  e.g.  p13")
            else:
                print("keys: d 0 9 m s x p<NN> q")
    except (KeyboardInterrupt, EOFError):
        print()
    finally:
        servo.close()
        print("Closed. Bye.")


if __name__ == "__main__":
    sys.exit(main())
