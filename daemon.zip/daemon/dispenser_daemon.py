"""
Dispenser Daemon — runs on the Raspberry Pi 5 (the kiosk terminal).
Exposes POST /dispense → drives the card-dispenser servo to eject one card.

This is the HTTP service the kiosk calls on the "collect card" tap
(kiosk .env: VITE_DISPENSER_URL=http://localhost:5003 — localhost = the Pi).

Hardware (servo → Pi 5), per dispenser_test.py:
    Signal (orange/yellow) → GPIO 12  (physical pin 32)
    V+     (red)           → 5V        (separate 5V supply if it browns out)
    GND    (brown/black)   → GND       (MUST share GND with the Pi)
Pulse: 50 Hz, 544 µs = 0°, 2400 µs = 180°. Motion: 180° → hold → home → detach.

The servo driver itself is shared with dispenser_test.py so the test tool and the
daemon can never drift apart.

Run (on the Pi):
    python3 dispenser_daemon.py            # software PWM (gpiozero) — default
    sudo python3 dispenser_daemon.py --hw  # hardware PWM (kernel /sys/class/pwm)

Endpoints:
    POST /dispense → {"ok": true}            (or 429 busy / 503 no-servo / 500 error)
    GET  /health   → {"status": "ok", ...}
"""

import sys
import threading
from datetime import datetime, timezone
from flask import Flask, jsonify

import dispenser_test as servo_drv   # reuse the proven servo driver (SERVO_PIN, make_servo, dispense)

app = Flask(__name__)


@app.after_request
def add_cors(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'POST, GET, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    return response


_lock = threading.Lock()          # one dispense at a time
_servo = None
_servo_err = None


def _get_servo():
    """Create the servo once (lazily) and reuse it. Returns (servo_or_None, error_or_None)."""
    global _servo, _servo_err
    if _servo is not None or _servo_err is not None:
        return _servo, _servo_err
    try:
        _servo = servo_drv.make_servo(servo_drv.SERVO_PIN)
        backend = 'hardware' if servo_drv.USE_HW else 'software'
        print(f"[dispenser_daemon] servo ready on GPIO {servo_drv.SERVO_PIN} ({backend} PWM)")
    except Exception as e:
        _servo_err = str(e)
        print(f"[dispenser_daemon] servo init failed: {e}")
    return _servo, _servo_err


@app.post("/dispense")
def dispense():
    # Reject overlapping dispenses instead of queuing them.
    if not _lock.acquire(blocking=False):
        return jsonify({"ok": False, "error": "busy"}), 429
    try:
        servo, err = _get_servo()
        if servo is None:
            return jsonify({"ok": False, "error": err or "servo unavailable"}), 503
        servo_drv.dispense(servo)
        print(f"[dispenser_daemon] dispensed at {datetime.now(timezone.utc).isoformat()}")
        return jsonify({"ok": True})
    except Exception as e:
        print(f"[dispenser_daemon] dispense error: {e}")
        return jsonify({"ok": False, "error": str(e)}), 500
    finally:
        _lock.release()


@app.get("/health")
def health():
    _, err = (_servo, _servo_err)
    return jsonify({
        "status": "ok",
        "service": "dispenser_daemon",
        "servo": "error" if err else ("ready" if _servo else "uninitialised"),
    })


if __name__ == "__main__":
    servo_drv.USE_HW = "--hw" in sys.argv
    _get_servo()   # park the servo at home + surface wiring errors at startup
    app.run(host="0.0.0.0", port=5003)
