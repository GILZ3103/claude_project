"""Face recognition pipeline modules."""
